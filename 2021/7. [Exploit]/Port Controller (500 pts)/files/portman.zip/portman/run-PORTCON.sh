#!/bin/sh
#
# R0 8-PORT CONTROLLER CTF CHALLENGE
# by Saumil Shah @therealsaumil

TAG="PORTCON"
HOSTFWD="hostfwd=tcp::9998-:9998,hostfwd=tcp::9999-:9999,hostfwd=tcp::8080-:8080"

EXT2="${TAG}.ext2"
APPEND="rootwait rw root=/dev/sda console=ttyS0,115200"
DRIVE="format=raw"

./qemu-bin/qemu-system-mipsel-6.1.0 \
    -M malta \
    -m 256 \
    -kernel ${TAG}-vmlinux.elf \
    -drive ${DRIVE},file=${EXT2} \
    -append "${APPEND}" \
    -net user,${HOSTFWD} -net nic \
    -nographic
