The R0 8-PORT CONTROLLER is a Smart IoT device that provides 8 DAC (Digital to Analog Converter) outputs. It can be used for home automation and other applications that require simple switching functionality. The R0 8-PORT CONTROLLER features an easy to use Web UI that makes it accessible from within your home's internal LAN.

1. Download portman.zip
2. Find the RCE in the target, and write an exploit to reliably invoke `/bin/sh`.
3. For the final phase, you will be required to exploit an "in production" R0 8-PORT CONTROLLER running on challenges.ph0wn.org:8080

Live Long and Prosper ||//_

The zip contains:

-  `run-PORTCON.sh` shell script to run the CTF challenge in QEMU
-  `PORTCON.ext2` root filesystem image
- `PORTCON-vmlinux.elf` Linux kernel
-  `qemu-bin` Statically compiled QEMU binary
- `share` contains some QEMU ROM images

Use a Linux x86-64 system with kernel 3.x or above, and run `./run-PORTCON.sh`.
The script will invoke QEMU and drop you into the console of the R0 8-PORT CONTROLLER.


